#ifndef __H_AREA_ACCELERATOR_H__
#define __H_AREA_ACCELERATOR_H__

#endif
